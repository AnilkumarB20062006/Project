# Zepto Data & AI Platform — Capstone Project

One repository, three internally-linked modules built for Zepto's analytics
guild: a data-engineering pipeline (`/data_pipeline`), an analytics +
predictive-modeling pipeline (`/analytics`), and a GenAI support assistant
(`/support_assistant`).

| Module | Marks | Status |
|---|---|---|
| `/data_pipeline` | 25 | Code complete, parsing logic unit-tested offline against real-markup fixtures, downstream (clean → db → queries) pipeline verified end-to-end. Live scrape must be run on a machine with normal internet access (see note below). |
| `/analytics` | 50 | Complete — run end-to-end in full, every chart/metric/artifact in this repo is real output, not illustrative. |
| `/support_assistant` | 25 | Code complete, full LangGraph + FastAPI wiring verified end-to-end offline (16 passing tests). Real embedding model must be downloaded on a machine with normal internet access on first run (see note below). |

## Setup

This repository uses **one consolidated `requirements.txt`** at the repo
root covering all three modules (rather than one per module).

```bash
python -m venv .venv && source .venv/bin/activate   # optional but recommended
pip install -r requirements.txt
```

Python 3.11+ recommended (built and tested on 3.12).

## Running each module end to end

```bash
# Module 1 — Data Pipeline
cd data_pipeline
python run_pipeline.py          # scrape -> clean -> load SQLite -> run SQL queries
pytest tests/ -v                # offline parsing tests (no network needed)

# Module 2 — Analytics
cd ../analytics
python 01_eda.py                # profiling, cleaning, EDA charts -> charts/, eda_report.md
python 02_modeling.py           # classifiers, tuning, regression -> charts/, modeling_report.md, model_pipeline.joblib

# Module 3 — Support Assistant
cd ../support_assistant
python vectorstore.py           # ingest the 8 policy docs into ChromaDB (downloads all-MiniLM-L6-v2 on first run)
uvicorn main:app --host 0.0.0.0 --port 7860   # MOCK_LLM defaults to 1 (graded baseline)
python capture_examples.py      # (in another terminal, or after stopping uvicorn) records 2 example calls
pytest tests/ -v                # offline graph/API tests (no model download needed)

# Docker (support_assistant only, required baseline):
docker build -t zepto-support-assistant .
docker run -p 7860:7860 zepto-support-assistant
```

## Git workflow

This repo's history includes feature branches (`feature/data-pipeline`,
`feature/analytics-pipeline`, `feature/support-assistant`), each created,
committed to at least twice, and merged back into `main` — visible via:

```bash
git log --graph --all --oneline
```

## Design decisions summary (full detail in each module's own README)

### `/data_pipeline`
- Crawls category links from the site's own homepage sidebar (rather than
  hardcoding category URLs/IDs), greedily choosing the largest categories
  until ≥3 are picked and the running total clears 60 books.
- `price_inr = price_gbp * 105.50` — the required fixed baseline rate, no
  live lookup.
- Malformed rows: unparseable `price` → dropped (financial figure, don't
  fabricate); unparseable `rating` → median-imputed (low-risk ordinal
  field). See `data_pipeline/README.md` for the full justification.
- Schema: `categories(category_id PK, category_name UNIQUE)` ⟷
  `books(book_id PK, ..., category_id FK)`.
- The JOIN query ("10 highest-rated books per category") uses a
  `ROW_NUMBER() OVER (PARTITION BY ...)` window function, and is
  independently reproduced with `pd.merge` + `groupby().head(10)` — the two
  are compared with `.equals()` and confirmed identical.

### `/analytics`
- The raw Titanic dataset is loaded from the network/cache **exactly once**
  (`common.load_raw()`), immediately persisted as `titanic.csv` as an
  offline fallback; `02_modeling.py` never calls `sns.load_dataset` again —
  it reuses the same cleaned data via `common.load_and_clean()`.
- Missing-value handling follows the stated percentage-threshold rule,
  measured exactly: `age` 19.87% → median-impute; `embarked`/`embark_town`
  0.22% → drop rows; `deck` 77.22% → drop column (too sparse to impute
  reliably, and not required by any downstream task).
- Preprocessing (imputation, one-hot encoding, `StandardScaler`) is a single
  `ColumnTransformer` inside a `Pipeline`, fit only on the training split.
- Three classifiers (Logistic Regression, Decision Tree, Random Forest) are
  compared on accuracy/precision/recall/F1/AUC; SMOTE is applied to the
  training fold only; Random Forest is tuned with `GridSearchCV` and
  reports its OOB score; a separate linear regression predicts `fare` and
  reports MAE/RMSE/R²/Adjusted R² plus a residual-based heteroscedasticity
  call. The best full pipeline (preprocessing + estimator) is saved with
  `joblib` and reload-verified on raw input.
- Full numbers, all 11 charts, and every written interpretation are in
  `analytics/eda_report.md`, `analytics/modeling_report.md`, and
  `analytics/charts/`.

### `/support_assistant`
- 8-document corpus, one chunk per document (all well under the chunking
  threshold), embedded locally with `sentence-transformers/all-MiniLM-L6-v2`
  and stored in a ChromaDB collection — no API key, no paid service.
- A 3-node LangGraph `StateGraph` (`classify_intent` → conditional edge →
  `retrieve_and_answer` / `direct_answer`) with every generation step gated
  behind `MOCK_LLM` (defaults to the fully deterministic, offline graded
  baseline). Retrieval itself always runs for real in both modes.
  Full stage-by-stage architecture diagram in `support_assistant/README.md`.
- `POST /ask` (FastAPI) returns a Pydantic-validated `{answer, sources,
  confidence}` response; a `Dockerfile` builds and serves it locally on
  port 7860.

## A note on where this was built

This repository was authored and tested inside a sandboxed environment
whose network access is restricted to a small package-registry allow-list —
it cannot reach `books.toscrape.com` (Module 1's scrape target) or
`huggingface.co` (Module 3's embedding-model host). Concretely, this means:

- **Module 1**: the scraper's parsing logic (category discovery, listing-page
  parsing, pagination) was unit-tested offline against saved HTML fixtures
  that mirror the live site's exact markup (`data_pipeline/tests/`, 4/4
  passing), and the downstream clean → SQLite → SQL-queries →
  `pd.merge`-equivalence chain was run and verified end-to-end against a
  representative dataset shaped like the real scrape output. **Run
  `python run_pipeline.py` on a machine with normal internet access** to
  produce the real, gradeable `books_raw.csv` / `books_clean.csv` /
  `books.db`.
- **Module 2**: needed no workaround — `raw.githubusercontent.com` (where
  seaborn's dataset loader actually fetches from) was reachable, so this
  module was run for real, in full, in this environment. Every chart,
  number, and saved artifact in `/analytics` is genuine output.
- **Module 3**: the LangGraph graph, ChromaDB storage/retrieval, FastAPI
  endpoint, and Pydantic validation were all tested end-to-end here using a
  small dependency-injected fake embedder (`support_assistant/tests/
  fake_embedder.py`) standing in for `all-MiniLM-L6-v2`, since the real
  model's weights couldn't be downloaded in this sandbox (16/16 tests
  passing). **Run `python vectorstore.py` on a machine with normal internet
  access** the first time — it downloads the real model automatically
  (~90 MB, one-time) — before serving the API for grading.

Everything above is ordinary "run this on your own machine" setup, no
different from what any grader/CI runner would do for a project with a live
scrape target and a downloaded model — it's called out here only for
transparency about what was and wasn't executed inside this particular
build environment.
